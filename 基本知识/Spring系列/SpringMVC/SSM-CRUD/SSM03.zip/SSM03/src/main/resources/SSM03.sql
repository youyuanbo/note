use ssm;

drop table if exists table_emp;

create table table_emp
(
  emp_id   int          not null auto_increment,
  emp_name varchar(255) not null,
  gender   char(1)      not null,
  email    varchar(255),
  dept_id  int,
  primary key (emp_id),
  foreign key (dept_id) references table_dept (dept_id)
);


drop table if exists table_dept;

create table table_dept
(
  dept_id   int          not null auto_increment,
  dept_name varchar(255) not null,
  primary key (dept_id)
);