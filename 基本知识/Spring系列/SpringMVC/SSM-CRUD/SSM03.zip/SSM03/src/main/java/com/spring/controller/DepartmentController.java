package com.spring.controller;


import com.spring.pojo.Department;
import com.spring.utils.Message;
import com.spring.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 出力和部门有关的请求
 */
@Controller
@RequestMapping("/dept")
public class DepartmentController {

    @Autowired
    DepartmentService departmentService;

    /**
     * 查询所有的部门信息
     * @return 返回查询到的部门信息
     */
    @ResponseBody
    @RequestMapping("/getDepts")
    public Message getDepts(){
        List<Department> departments = departmentService.getDepts();
        return Message.success().add("depts", departments);
    }
}
