package com.spring.service;

import com.spring.mapper.EmployerMapper;
import com.spring.pojo.Employer;
import com.spring.pojo.EmployerExample;
import com.spring.pojo.EmployerExample.Criteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    EmployerMapper employerMapper;


    public List<Employer> getAll() {
        return employerMapper.selectByExampleWithDept(null);

    }

    public void insertEmp(Employer employer) {
        employerMapper.insertSelective(employer);
    }

    /**
     * 检验用户名是否可用
     * 如果返回的count数为0，表示数据库中没有该名字，该用户名可以使用，否则不可用
     * @param empName 新增用户姓名
     * @return
     */
    public Boolean checkUserName(String empName) {
        EmployerExample example = new EmployerExample();
        Criteria criteria = example.createCriteria();
        criteria.andEmpNameEqualTo(empName);

        long count = employerMapper.countByExample(example);
        return count == 0;
    }

    public Employer getEmp(Integer empId) {

        return employerMapper.selectByPrimaryKey(empId);
    }

    /**
     * 更新员工信息
     * @param employer
     */
    public void updateEmp(Employer employer) {
        employerMapper.updateByPrimaryKeySelective(employer);
    }

    /**
     * 删除单个员工信息
     * @param empId
     */
    public void deleteEmp(Integer empId) {
        employerMapper.deleteByPrimaryKey(empId);
    }

    /**
     * 根据ID批量删除
     * @param idList
     */
    public void deleteEmpBatch(List<Integer> idList) {
        EmployerExample example = new EmployerExample();
        Criteria criteria = example.createCriteria();
        criteria.andEmpIdIn(idList);
        employerMapper.deleteByExample(example);

    }
}
