package com.spring.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.spring.pojo.Employer;
import com.spring.utils.Message;
import com.spring.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    /**
     * 查询员工数据（分页查询）
     *
     * @return
     */
    /*
    @RequestMapping("/getEmps")
    public String getEmps(@RequestParam(value = "pn", defaultValue = "1") Integer pn, Model model){

        //引用PageHelper分页插件
        //在查询之前，调用startPage方法，传入页码和每页的数据行数
        PageHelper.startPage(pn, 5);
        //startPage方法后面的方法就是分页查询
        List<Employer> employers = employeeService.getAll();
        //使用PageInfo包装查询后的信息
        //PageInfo中封装了详细的分页信息，包括查询出的数据
        //5 :表示连续现实的页数
        PageInfo pageInfo = new PageInfo(employers, 5);
        model.addAttribute("pageInfo", pageInfo);
        return "list";
    }
    */
    @ResponseBody
    @RequestMapping("/getEmps")
    public Message getEmpsWithJson(@RequestParam(value = "pn", defaultValue = "1") Integer pn) {
        //引用PageHelper分页插件
        //在查询之前，调用startPage方法，传入页码和每页的数据行数
        PageHelper.startPage(pn, 400);
        //startPage方法后面的方法就是分页查询
        List<Employer> employers = employeeService.getAll();
        //使用PageInfo包装查询后的信息
        //PageInfo中封装了详细的分页信息，包括查询出的数据
        //5 :表示连续现实的页数
        PageInfo pageInfo = new PageInfo(employers, 5);
        return Message.success().add("pageInfo", pageInfo);
    }


    /**
     * 新增员工信息
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/insertEmp", method = RequestMethod.POST)
    public Message insertEmp(@Valid Employer employer, BindingResult result) {
        if (result.hasErrors()){
            // 校验失败，返回失败信息
            //封装验证信息
            Map<String, Object> map = new HashMap<>();
            //提取校验失败的所有信息
            List<FieldError> fieldErrors = result.getFieldErrors();
            //遍历错误信息
            for (FieldError fieldError: fieldErrors) {
                System.out.println("错误的字段名：" + fieldError.getField());
                System.out.println("错误信息:"+ fieldError.getDefaultMessage());
                map.put(fieldError.getField(), fieldError.getDefaultMessage());
            }
            return Message.fail().add("errorField", map);
        }else {
            employeeService.insertEmp(employer);
            return Message.success();
        }
    }

    /**
     * 检查用户名是否可用
     * 使用JSR303校验
     * 1、导入Hibernate-Validator包
     *
     *
     * @param empName
     * @return
     */
    @ResponseBody
    @RequestMapping("/checkUserName")
    public Message ckeckUserName(String empName) {
        //先判断用户名是否符合规则
        String regex = "(^[a-zA-Z 0-9_-]{6,16}$)|(^[\\u2E80-\\u9FFF]{2,5})";
        if (!empName.matches(regex)) {
            return Message.fail().add("validate_info", "用户名可以是2-5为中文或者6-16为英文和数字的组合。");
        }

        //如果用户名符合规则，再在数据库中查询是否重复
        Boolean bool = employeeService.checkUserName(empName);
        if (bool) {
            return Message.success();
        } else {
            return Message.fail().add("validate_info", "用户名不可用");
        }
    }

    /**
     * 根据ID查询员工信息
     * @param empId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/getEmp/{empId}", method = RequestMethod.GET)
    public Message getEmp(@PathVariable("empId") Integer empId){
        Employer employer = employeeService.getEmp(empId);
        return Message.success().add("employer", employer);
    }

    /**
     * 更新员工信息
     * @param employer
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateEmp/{empId}", method = RequestMethod.POST)
    public Message updateEmp(Employer employer){
        employeeService.updateEmp(employer);
        return Message.success();
    }


    /**
     * 删除单个员工数据
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/deleteEmp/{empIds}", method = RequestMethod.DELETE)
    public Message deleteEmp(@PathVariable("empIds") String empIds){
        //批量删除
        if (empIds.contains("-")){
            String[] split = empIds.split("-");
            List<Integer> idList = new ArrayList<>();
            for(String empId : split){
                idList.add(Integer.parseInt(empId));
                employeeService.deleteEmpBatch(idList);
            }
        }else {
            //单个删除
            Integer empId = Integer.parseInt(empIds);
            employeeService.deleteEmp(empId);
        }
        return Message.success();
    }


}
