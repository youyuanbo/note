package com.spring.test;

import com.spring.mapper.DepartmentMapper;
import com.spring.mapper.EmployerMapper;
import com.spring.pojo.Department;
import com.spring.pojo.Employer;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.UUID;

/**
 * 使用Spring-test单元测试模块
 * 1. 使用@ContextConfiguration注解指定配置文件位置
 * 2. 使用@RunWith指定使用使用Spring-test中的单元测试模块
 * 3. 直接Autowired需要使用的主键即可
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class TestDeptMapper {

    @Autowired
    DepartmentMapper departmentMapper;

    @Autowired
    EmployerMapper employerMapper;

    @Autowired
    SqlSession sqlSession;

    @Test
    public void testInsert(){

        /*
        //原始测试
        //1. 创建SpringIOC容器
        ApplicationContext ioc = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        //2. 从容器中获取mapper
        DepartmentMapper bean = ioc.getBean(DepartmentMapper.class);
        */


        //插入部门数据
        departmentMapper.insertSelective(new Department(null,"市场部"));
//        departmentMapper.insertSelective(new Department(null,"测试部"));

        //插入部门数据
//        employerMapper.insertSelective(new Employer(null, "小梁", "F", "312202171@qq.com", 1));
//        employerMapper.insertSelective(new Employer(null, "小游", "M", "1047795132@qq.com", 2));
        // 批量生成测试数据
        /*
        EmployerMapper mapper = sqlSession.getMapper(EmployerMapper.class);
        for (int i = 0; i < 1000; i++) {
//            // 使用UUID生成姓名
            String name = UUID.randomUUID().toString().substring(0, 5) + i;
            mapper.insertSelective(new Employer(null, name, "M", name + "@centos.com",1));
        }
        */
    }

    @Test
    public void testSelect(){
        Department department = departmentMapper.selectByPrimaryKey(1);
        System.out.println(department);

        Employer employer = employerMapper.selectByPrimaryKeyWithDept(2);
        System.out.println(employer);
    }

}
